package bank.user.model;

import java.util.List;
import bank.user.entity.Account;
import lombok.Data;

/**
 * Model class for User entity
 */
@Data
public class UserModel
{
		private int userNumber;
		private String name;
		private int contact;
		private String address;
		private List<Account> accounts;	
}
