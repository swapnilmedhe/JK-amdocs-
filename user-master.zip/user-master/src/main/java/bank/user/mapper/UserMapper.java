package bank.user.mapper;

import org.springframework.stereotype.Component;
import bank.user.entity.User;
import bank.user.model.UserModel;

/**
 * Class to convert From entity to Model and vice-versa
 */
@Component
public class UserMapper {
	
	 /**
	   * To convert user entity to model 
	   * @param u user entity 
	   * @return userModel
	   */
	public UserModel convertToUserModel(User u)
	{
		UserModel m=new UserModel();
		m.setUserNumber(u.getUserNumber());
		m.setName(u.getName());
		m.setContact(u.getContact());
		m.setAddress(u.getAddress());
		m.setAccounts(u.getAccounts());
		return m;
		
	}
	
	 /**
	   * To convert user model to User
	   * @param m User Model to cinver to entity
	   * @return User
	   */
	public User convertToUserEntity(UserModel m)
	{
		User u=new User();
		u.setUserNumber(m.getUserNumber());
		u.setName(m.getName());
		u.setContact(m.getContact());
		u.setAddress(m.getAddress());
		u.setAccounts(m.getAccounts());
		return u;
	}
	
	//ObjectMapper
	

}
