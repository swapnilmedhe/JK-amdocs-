package bank.user.daoImpl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import bank.user.dao.UserDao;
import bank.user.entity.User;
import bank.user.exception.ResourceNotFoundException;
import bank.user.model.UserModel;
import bank.user.repository.UserRepository;

/**
 * @inheritDoc
 */
@Service
public class UserDaoImpl implements UserDao{
	
	@Autowired
	private UserRepository userRepo;
	
	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	@Override
	public User findUserByUserNumber(int no) throws ResourceNotFoundException{
		User u= userRepo.findByUserNumber(no);
		if(u==null)
			throw new ResourceNotFoundException("User not found for this user number:: " + no);
		logger.info("User fetched for account no {}",no);
		return u;	
	}

	@Override
	public void remove(int no) throws ResourceNotFoundException {
		User u=findUserByUserNumber(no);
		userRepo.delete(u);	
		logger.info("User deleted for user no {}",no);
	}

	@Override
	public void add(User u) {
		userRepo.save(u);	
		logger.info("Following user added with user no {}",u.getUserNumber());
	}

	@Override
	public void update(int no, UserModel userDetails) throws ResourceNotFoundException {
		User u=findUserByUserNumber(no);
		u.setAddress(userDetails.getAddress());
		u.setContact(userDetails.getContact());
		u.setName(userDetails.getName());
		userRepo.save(u);
		logger.info("User updated of user no ",no);	
		
	}

	@Override
	public List<User> findAll() {
		return userRepo.findAll();
	}
	
	@Override
	public void patch(int no, Map<String, Object> changes) throws ResourceNotFoundException{
		User u=findUserByUserNumber(no);	
		changes.forEach(
                (change, value) -> {
                    switch (change){
                        case "name": u.setName((String) value); break;
                        case "contact": u.setContact((Integer) value); break;
                        case "address": u.setAddress((String) value); break;
                    }
                }
        );		
		userRepo.save(u);
		
	}

}
