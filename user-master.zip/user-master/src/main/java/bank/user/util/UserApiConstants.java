package bank.user.util;

public class UserApiConstants {
	public static final String allUsers ="/users";
	public static final String getbyUserNumber="/users/{userNumber}";
	public static final String addUser="/users";
	public static final String deleteUser="/users/{userNumber}";
	public static final String addAccounts="/users";
	public static final String getUser="/user/{userNumber}";
}
