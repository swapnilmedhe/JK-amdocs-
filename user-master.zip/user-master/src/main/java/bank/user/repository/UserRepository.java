package bank.user.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import bank.user.entity.User;

/**
* Repository interface extending JPA repository interacting with database
*/
public interface UserRepository extends JpaRepository<User,Integer>{
	
	/**
	   * This method is used to fetch user based on User number
	   * @param userNumber
	   * @return User
	   */
	User findByUserNumber(Integer userNumber);
	
}
