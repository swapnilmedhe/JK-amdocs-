package bank.user.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import bank.user.entity.User;
import bank.user.exception.ResourceNotFoundException;
import bank.user.model.UserModel;
import bank.user.service.UserService;
import bank.user.util.UserApiConstants;

/**
* Controller class for User Microservice
*/
@RestController
public class UserController {
	
	@Autowired
	private UserService service;
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	/**
	   * To fetch all existing users.
	   * @return List<UserModel> A list of all the users
	   */
	@GetMapping(UserApiConstants.allUsers)
	public List<UserModel> getAllUsers() {
		return service.getAll();
		
	}
	
	/**
	   * To get the user details based on user number
	   * @param userNumber 
	   * @return userModel
	   * @exception ResourceNotFoundException if user not available with the specified user Number.
	   * @see ResourceNotFoundException
	   */
	@GetMapping(UserApiConstants.getbyUserNumber)
	public ResponseEntity<UserModel> getUserByUserNumber(@PathVariable(value = "userNumber") int userNumber) throws ResourceNotFoundException
	{
		UserModel userModel=null;
		try {
			userModel = service.getUser(userNumber);
		} 
		catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
			throw e;
		}	
		return ResponseEntity.ok().body(userModel);
	}
	
	/**
	   * To add a new user.
	   * @param userModel details of the account to be added 
	   * @return ResponseEntity<String>
	   */
	@PostMapping(UserApiConstants.addUser)
	public ResponseEntity<String> createUser(@Valid @RequestBody UserModel userModel) {
		service.add(userModel);
		return ResponseEntity.status(HttpStatus.CREATED).body("created");
	}
	
	/**
	   * To delete a user
	   * @param userNumber 
	   * @return ResponseEntity<String>
	   * @exception ResourceNotFoundException if user not available with the specified user Number.
	   * @see ResourceNotFoundException
	   */
	@DeleteMapping(UserApiConstants.deleteUser)
	public ResponseEntity<String> delete(@PathVariable(value = "userNumber") int userNumber) throws ResourceNotFoundException {
		try {
			service.remove(userNumber);
		}
		catch(ResourceNotFoundException e){
			logger.error(e.getMessage());
			throw e;
		}
		return ResponseEntity.ok().body("deleted");
	}
	
	/**
	   * To update details of an existing user
	   * @param userNumber for the user to update
	   * @param userModel the new details that needs to be updated
	   * @return ResponseEntity<String>
	   * @exception ResourceNotFoundException if user not available with the specified user Number.
	   * @see ResourceNotFoundException
	   */
	@PatchMapping("/users/{userNumber}")
	public ResponseEntity<?> update(@PathVariable(value = "userNumber") int userNumber,
	        @RequestBody UserModel accModel) throws ResourceNotFoundException {
	    service.update(userNumber,accModel);
		return ResponseEntity.ok().build();
	}
	
	@PatchMapping("/users/try/{userNumber}")
	public ResponseEntity<?> update(@PathVariable(value = "userNumber") int userNumber,
	        @RequestBody Map<String, Object> updates ) throws ResourceNotFoundException {
	    service.patch(userNumber,updates);
		return ResponseEntity.ok().build();
	}
	
	
	
	/*Made the below API for communication with account so that account can store account
	 * holder as user entity and there is no need of conversion from user model to user there
	 */
	/**
	   * To get user based on user number
	   * @param userNumber 
	   * @return User
	   * @exception ResourceNotFoundException if user not available with the specified user Number.
	   * @see ResourceNotFoundException
	   */
	@GetMapping(UserApiConstants.getUser)
	public User getUser(@PathVariable(value = "userNumber") int userNumber) throws ResourceNotFoundException
	{
		User user=null;
		try {
			user = service.get(userNumber);
		} catch (ResourceNotFoundException e) {
			logger.error(e.getMessage());
			throw e;
		}	
		return user;
	}
}
