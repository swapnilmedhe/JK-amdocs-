package bank.user.dao;

import java.util.List;
import java.util.Map;

import bank.user.entity.User;
import bank.user.exception.ResourceNotFoundException;
import bank.user.model.UserModel;

/**
 * DAO class to interact with database
 */
public interface UserDao 
{
	/**
	   * This method is used to fetch account based on user number.
	   * @param no user number for User
	   * @return User
	   * @exception ResourceNotFoundException if user not available with the specified user Number..
	   * @see ResourceNotFoundException
	   */
	 	public User findUserByUserNumber(int no) throws ResourceNotFoundException;
	 	
	 	 /**
		   * This method is used to delete user form database
		   * @param no user number for user
		   * @exception ResourceNotFoundException if user not available with the specified user Number.
		   * @see ResourceNotFoundException
		   */
	    public void remove(int no) throws ResourceNotFoundException;
	    /**
		   * This method is used to create a new user.
		   * @param u  to be created
		   * @exception ResourceNotFoundException if user not available with the specified user Number.
		   * @see ResourceNotFoundException
		   */
	    public void add(User u);
	    
	    /**
		   * This method is used to update an existing user.
		   * @param no user number of user to be updated
		   * @param userDetails new details of user
		   * @exception ResourceNotFoundException if user not available with the specified user Number.
		   * @see ResourceNotFoundException
		   */
	    public void update(int no, UserModel userDetails) throws ResourceNotFoundException;
	    
	    /**
		   * Return a list of all users
		   * @return List<User> A list of all users
		   */
	    public List<User> findAll();
	    public void patch(int no, Map<String, Object> changes) throws ResourceNotFoundException;

}
