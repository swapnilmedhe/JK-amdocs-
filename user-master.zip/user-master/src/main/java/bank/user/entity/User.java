package bank.user.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entity class for User
 */

@Entity
@Table(name="User")
@Data
@NoArgsConstructor
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;

	@Column(name="userNumber",unique=true,nullable=false)
	private int userNumber;
	
	@Column(name="name")
	@NotNull(message="Name cannot be null")
	private String name;
		
	@Column(name="contact")
	@NotNull(message="Contact cannot be null")
	private int contact;
	
	@Column(name="address")
	@NotNull(message=" Address cannot be null")
	private String address;
	
	//@Transient
	@JsonManagedReference
	@OneToMany(mappedBy = "accountHolder",fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Account> accounts;
    
	public User(@NotNull(message = "userId cannot be null") int userNumber,
			@NotNull(message = "Name cannot be null") String name,
			@NotNull(message = "Contact cannot be null") int contact,
			@NotNull(message = " Address cannot be null") String address) {
		super();
		this.userNumber = userNumber;
		this.name = name;
		this.contact = contact;
		this.address = address;
	}
}
