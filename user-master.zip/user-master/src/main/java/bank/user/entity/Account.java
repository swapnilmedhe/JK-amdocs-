package bank.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

/**
 * Entity class for Account
 */
@Entity
@Table(name="Account")
@Data
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="account_Number",unique=true)
	@NotNull(message=" Account Number cannot be null")
	private Long accNumber;
	
	@Column(name="branch")
	@NotNull(message=" Account Branch cannot be null")
	private String accBranch;
	
	@Column(name="type")
	@NotNull(message=" Account Type cannot be null")
	private String accType;
	
	@Column(name="balance")
	private int accBalance;
	
	@JsonBackReference
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "userId")
	private User accountHolder;
  
	public Account() {
		super();
	}

	public Account(@NotNull(message = " Account Number cannot be null") Long accNumber,
			@NotNull(message = " Account Branch cannot be null") String accBranch,
			@NotNull(message = " Account Type cannot be null") String accType, int accBalance) {
		super();
		this.accNumber = accNumber;
		this.accBranch = accBranch;
		this.accType = accType;
		this.accBalance = accBalance;
	}
  	
}
