package bank.user.service;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import bank.user.entity.User;
import bank.user.exception.ResourceNotFoundException;
import bank.user.model.UserModel;

/**
* UserService acts as a service layer.It provides communication 
* between the controller and Dao
*/
public interface UserService {
	
	/**
	 * To fetch all existing users.
	 * @return List<UserModel> A list of all the users
	 */
	List<UserModel> getAll();
	
	/**
	 * To get the user details based on user number
	 * @param userNumber 
	 * @return userModel
	 * @exception ResourceNotFoundException if user not available with the specified user Number.
	 * @see ResourceNotFoundException
	 */
	UserModel getUser(int userNumber) throws ResourceNotFoundException;
	
	/**
	 * To add a new user.
	 * @param userModel details of the user to be added 
	 */
	void add(@Valid UserModel userModel);
	
	/**
	 * To delete a user
	 * @param userNumber 
	 * @exception ResourceNotFoundException if user not available with the specified user Number.
	 * @see ResourceNotFoundException
	 */
	void remove(int userNumber) throws ResourceNotFoundException;
	
	/**
	 * To update details of an existing user
	 * @param userNumber for the user to update
	 * @param userModel the new details that needs to be updated
	 * @exception ResourceNotFoundException if user not available with the specified user Number.
	 * @see ResourceNotFoundException
	 */
	void update(int userNumber,UserModel userDetails) throws ResourceNotFoundException;
	
	/**
	 * To get the user based on user number
	 * @param userNumber 
	 * @return User
	 * @exception ResourceNotFoundException if user not available with the specified user Number.
	 * @see ResourceNotFoundException
	 */
	User get(int userNumber)throws ResourceNotFoundException;
	public void patch(int no, Map<String, Object> changes) throws ResourceNotFoundException;

}
