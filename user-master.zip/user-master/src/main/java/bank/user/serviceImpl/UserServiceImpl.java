package bank.user.serviceImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bank.user.dao.UserDao;
import bank.user.entity.User;
import bank.user.exception.ResourceNotFoundException;
import bank.user.mapper.UserMapper;
import bank.user.model.UserModel;
import bank.user.service.UserService;

/**
 * @inheritDoc
 */
@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserMapper map;
	@Autowired
    private UserDao userdao;
	
	public List<UserModel> getAll()
	{
		List<User> users= userdao.findAll();
		List<UserModel> userModels=new ArrayList<>();
		Iterator<User> it=users.iterator();
		while(it.hasNext())
		{
			userModels.add(map.convertToUserModel(it.next()));
		}
		return userModels;
	}
	
	public UserModel getUser(int userNumber) throws ResourceNotFoundException
	{
		User user=userdao.findUserByUserNumber(userNumber);
		UserModel userModel=map.convertToUserModel(user);
		return userModel;
	}


	public void add(@Valid UserModel userModel) {
		User userEntity=map.convertToUserEntity(userModel);
		userdao.add(userEntity);	
	}

	public void remove(int userNumber) throws ResourceNotFoundException {
		
		userdao.remove(userNumber);	
	}
	public User get(int userNumber) throws ResourceNotFoundException{
		return userdao.findUserByUserNumber(userNumber);
	}

	@Override
	public void update(int userNumber, UserModel userDetails) throws ResourceNotFoundException {
		userdao.update(userNumber, userDetails);
		
	}

	@Override
	public void patch(int no, Map<String, Object> changes) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		userdao.patch(no, changes);
		
	}

}
