package bank.user;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import bank.user.controller.UserController;
import bank.user.dao.UserDao;
import bank.user.daoImpl.UserDaoImpl;
import bank.user.entity.User;
import bank.user.exception.ResourceNotFoundException;
import bank.user.model.UserModel;
import bank.user.service.UserService;

@RunWith(MockitoJUnitRunner.class)
class UserServiceTest {
	
	@Mock
	UserDao userdao;

	@InjectMocks
	UserService userservice;

	@Test
	void testGet() throws ResourceNotFoundException {
		//fail("Not yet implemented");
		/*User user=new User();
		user.setName("neha");
		when(userdao.findUserByUserNumber(12)).thenReturn(user);
		assertEquals("neha",userservice.get(12).getName());*/
	}

}
