package bank.user;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

//import antlr.collections.List;
import bank.user.controller.UserController;
import bank.user.model.UserModel;
import bank.user.service.UserService;

@SpringBootTest
class UserControllerTest {
	
	@Mock
	UserService userServiceMock;

	@InjectMocks
	UserController usercontroller;
	

	@Test
	void testGetAllUsers() {
		UserModel user=new UserModel();
		user.setName("neha");
		List<UserModel> lr=new ArrayList<>();
		lr.add(user);
		when(userServiceMock.getAll()).thenReturn(lr);
		assertEquals("neha",usercontroller.getAllUsers().get(0).getName());
	}

}
